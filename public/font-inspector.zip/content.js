(() => {
  if (window.__fontInspectorLoaded) return;
  window.__fontInspectorLoaded = true;

  let active = false;
  let pinEnabled = true;
  let badge = null;       // small hover label
  let panel = null;       // full detail panel (on click)
  let lastTarget = null;
  let copiedToast = null;

  // ── Helpers ──

  // Strip framework prefixes like Next.js __FontName_hash → FontName
  function cleanFontName(name) {
    // Next.js pattern: __Inter_abc123 or __Inter_Tight_abc123
    let cleaned = name.replace(/^__/, '').replace(/_[a-f0-9]{6,}$/i, '');
    // Convert remaining underscores to spaces (e.g., Inter_Tight → Inter Tight)
    cleaned = cleaned.replace(/_/g, ' ');
    return cleaned;
  }

  function getComputedFont(el) {
    const cs = window.getComputedStyle(el);
    const fontFamily = cs.fontFamily;
    const rawFont = fontFamily.split(',')[0].trim().replace(/['"]/g, '');
    const primaryFont = cleanFontName(rawFont);
    return {
      family: primaryFont,
      rawFamily: rawFont,
      fullFamily: fontFamily,
      size: cs.fontSize,
      weight: cs.fontWeight,
      style: cs.fontStyle,
      lineHeight: cs.lineHeight,
      letterSpacing: cs.letterSpacing === 'normal' ? 'normal' : cs.letterSpacing,
      color: cs.color,
    };
  }

  function weightName(w) {
    const names = {
      '100': 'Thin', '200': 'Extra Light', '300': 'Light',
      '400': 'Regular', '500': 'Medium', '600': 'Semi Bold',
      '700': 'Bold', '800': 'Extra Bold', '900': 'Black'
    };
    return names[w] || w;
  }

  function rgbToHex(rgb) {
    const match = rgb.match(/\d+/g);
    if (!match || match.length < 3) return rgb;
    const hex = match.slice(0, 3).map(n => parseInt(n).toString(16).padStart(2, '0')).join('');
    return `#${hex}`;
  }

  // ── Font discovery ──

  function findFontUrlFromPerformance(fontFamily, rawFamily) {
    const normalized = fontFamily.toLowerCase().replace(/['"\\s-]/g, '');
    const rawNorm = rawFamily ? rawFamily.toLowerCase().replace(/['"\\s-]/g, '') : '';
    const entries = performance.getEntriesByType('resource');
    const fontExtensions = ['.woff2', '.woff', '.ttf', '.otf', '.eot'];
    const fontEntries = entries.filter(e =>
      fontExtensions.some(ext => e.name.toLowerCase().includes(ext))
    );
    for (const entry of fontEntries) {
      const urlLower = entry.name.toLowerCase().replace(/[-_]/g, '');
      if (urlLower.includes(normalized) || (rawNorm && urlLower.includes(rawNorm))) return entry.name;
    }
    return null;
  }

  function getAllFontResourceUrls() {
    const entries = performance.getEntriesByType('resource');
    const fontExtensions = ['.woff2', '.woff', '.ttf', '.otf', '.eot'];
    return entries
      .filter(e => fontExtensions.some(ext => e.name.toLowerCase().includes(ext)))
      .map(e => e.name);
  }

  function getStylesheetUrls() {
    const urls = new Set();
    for (const sheet of document.styleSheets) {
      if (sheet.href) urls.add(sheet.href);
    }
    document.querySelectorAll('link[rel="stylesheet"]').forEach(link => {
      if (link.href) urls.add(link.href);
    });
    return [...urls];
  }

  function getInlineFontFaces() {
    const fontFaces = [];
    for (const sheet of document.styleSheets) {
      try {
        for (const rule of sheet.cssRules || []) {
          if (rule instanceof CSSFontFaceRule) fontFaces.push(rule.cssText);
        }
      } catch (_) {}
    }
    return fontFaces;
  }

  // Extract structured font data directly from the browser's parsed CSS rules
  // This is the same data Chrome DevTools uses — no regex parsing needed
  function getParsedFontFaces(fontFamily, rawFamily) {
    const normalized = fontFamily.toLowerCase().replace(/['"]/g, '').trim();
    const normalizedCompact = normalized.replace(/[\s\-_]/g, '');
    // Also try matching the raw (possibly mangled) name
    const rawNorm = rawFamily ? rawFamily.toLowerCase().replace(/['"]/g, '').trim() : '';
    const rawCompact = rawNorm.replace(/[\s\-_]/g, '');
    const results = [];

    for (const sheet of document.styleSheets) {
      try {
        for (const rule of sheet.cssRules || []) {
          if (!(rule instanceof CSSFontFaceRule)) continue;

          const style = rule.style;
          const family = (style.getPropertyValue('font-family') || '').replace(/['"]/g, '').trim().toLowerCase();
          const familyCompact = family.replace(/[\s\-_]/g, '');

          const matches = family === normalized || familyCompact === normalizedCompact
            || (rawNorm && (family === rawNorm || familyCompact === rawCompact));
          if (!matches) continue;

          const weight = style.getPropertyValue('font-weight') || '400';
          const fontStyle = style.getPropertyValue('font-style') || 'normal';
          const src = style.getPropertyValue('src') || '';

          // Extract URLs from src
          const urls = [];
          const urlRegex = /url\(["']?([^"')]+)["']?\)/g;
          let m;
          while ((m = urlRegex.exec(src)) !== null) {
            // Resolve relative URLs using the stylesheet's base
            try {
              const base = sheet.href || window.location.href;
              urls.push(new URL(m[1], base).href);
            } catch {
              urls.push(m[1]);
            }
          }

          if (urls.length === 0) continue;

          // Pick best format
          const preferred = urls.find(u => /\.woff2/i.test(u))
            || urls.find(u => /\.woff(?!2)/i.test(u))
            || urls.find(u => /\.ttf/i.test(u))
            || urls.find(u => /\.otf/i.test(u))
            || urls[0];

          // Handle variable font weight ranges (e.g., "100 900")
          const weightParts = weight.trim().split(/\s+/);
          const singleWeight = weightParts[0];

          if (!results.some(r => r.url === preferred)) {
            results.push({
              url: preferred,
              weight: singleWeight,
              style: fontStyle,
              isVariableWeight: weightParts.length > 1,
              weightRange: weightParts.length > 1 ? weight : null,
            });
          }
        }
      } catch (_) { /* cross-origin stylesheet */ }
    }

    return results;
  }

  function getDocumentFontsInfo(fontFamily, rawFamily) {
    const normalized = fontFamily.toLowerCase().replace(/['"]/g, '').trim();
    const rawNorm = rawFamily ? rawFamily.toLowerCase().replace(/['"]/g, '').trim() : '';
    const results = [];
    for (const face of document.fonts) {
      const faceFamily = face.family.toLowerCase().replace(/['"]/g, '').trim();
      if ((faceFamily === normalized || faceFamily === rawNorm) && face.status === 'loaded') {
        results.push({
          family: face.family,
          weight: face.weight || '400',
          style: face.style || 'normal',
          unicodeRange: face.unicodeRange || '',
        });
      }
    }
    return results;
  }

  function sendFontMessage(type, fontFamily, extra) {
    const rawFamily = extra && extra.rawFamily;
    const perfUrl = findFontUrlFromPerformance(fontFamily, rawFamily);
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        type, fontFamily, rawFamily, directUrl: perfUrl,
        fontResourceUrls: getAllFontResourceUrls(),
        stylesheetUrls: getStylesheetUrls(),
        inlineFontFaces: getInlineFontFaces(),
        parsedFontFaces: getParsedFontFaces(fontFamily, rawFamily),
        documentFonts: getDocumentFontsInfo(fontFamily, rawFamily),
        pageUrl: window.location.href,
        ...extra
      }, (response) => {
        if (chrome.runtime.lastError) { resolve({ success: false }); return; }
        resolve(response || { success: false });
      });
    });
  }

  function downloadFont(fontFamily, rawFamily, weight, style) {
    return sendFontMessage('DOWNLOAD_FONT', fontFamily, {
      rawFamily,
      inspectedWeight: weight,
      inspectedStyle: style
    });
  }

  function downloadAllWeights(fontFamily, rawFamily) {
    return sendFontMessage('DOWNLOAD_ALL_WEIGHTS', fontFamily, { rawFamily });
  }

  function findReplica(fontFamily) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'FIND_REPLICA', fontFamily }, (response) => {
        if (chrome.runtime.lastError) { resolve({ success: false }); return; }
        resolve(response || { success: false });
      });
    });
  }

  // ── Hover Badge (mini label) ──

  function createBadge() {
    const el = document.createElement('div');
    el.className = 'fi-badge';
    el.innerHTML = `
      <span class="fi-badge-font"></span>
      <span class="fi-badge-sep">&middot;</span>
      <span class="fi-badge-size"></span>
      <span class="fi-badge-sep">&middot;</span>
      <span class="fi-badge-weight"></span>
      <span class="fi-badge-cta">Click to inspect</span>
    `;
    document.documentElement.appendChild(el);
    return el;
  }

  function updateBadge(info, x, y) {
    if (!badge) badge = createBadge();
    badge.querySelector('.fi-badge-font').textContent = info.family;
    badge.querySelector('.fi-badge-size').textContent = info.size;
    badge.querySelector('.fi-badge-weight').textContent = weightName(info.weight);

    // Position near cursor
    const pad = 14;
    badge.style.left = `${x + pad}px`;
    badge.style.top = `${y - 40}px`;

    // Reposition if offscreen
    requestAnimationFrame(() => {
      const rect = badge.getBoundingClientRect();
      if (rect.right > window.innerWidth - pad) {
        badge.style.left = `${x - rect.width - pad}px`;
      }
      if (rect.top < pad) {
        badge.style.top = `${y + 20}px`;
      }
    });

    badge.classList.add('fi-visible');
  }

  function hideBadge() {
    if (badge) badge.classList.remove('fi-visible');
  }

  // ── Full Detail Panel (on click) ──

  function createPanel() {
    const el = document.createElement('div');
    el.className = 'fi-tooltip fi-pinned';
    el.innerHTML = `
      <div class="fi-tooltip-header">
        <span class="fi-font-name"></span>
        <button class="fi-close-btn" title="Close">&times;</button>
      </div>
      <div class="fi-preview">
        <span class="fi-preview-text">Aa Bb Cc 123</span>
      </div>
      <div class="fi-grid">
        <div class="fi-prop">
          <div class="fi-prop-label">Size</div>
          <div class="fi-prop-value fi-mono" data-field="size"></div>
        </div>
        <div class="fi-prop">
          <div class="fi-prop-label">Weight</div>
          <div class="fi-prop-value" data-field="weight"></div>
        </div>
        <div class="fi-prop">
          <div class="fi-prop-label">Style</div>
          <div class="fi-prop-value" data-field="style"></div>
        </div>
        <div class="fi-prop">
          <div class="fi-prop-label">Line Height</div>
          <div class="fi-prop-value fi-mono" data-field="lineHeight"></div>
        </div>
        <div class="fi-prop">
          <div class="fi-prop-label">Spacing</div>
          <div class="fi-prop-value fi-mono" data-field="letterSpacing"></div>
        </div>
        <div class="fi-prop">
          <div class="fi-prop-label">Color</div>
          <div class="fi-prop-value" data-field="color">
            <div class="fi-color-row">
              <span class="fi-color-swatch"></span>
              <span class="fi-color-hex fi-mono"></span>
            </div>
          </div>
        </div>
        <div class="fi-prop" style="grid-column: 1 / -1;">
          <div class="fi-prop-label">Full Family</div>
          <div class="fi-prop-value fi-mono" data-field="fullFamily" style="font-size:11px !important;"></div>
        </div>
      </div>
      <div class="fi-download-row">
        <button class="fi-download-btn" title="Download this weight">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M7 1v8m0 0L4 6.5M7 9l3-2.5M2 11.5h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span class="fi-download-label">Download Font</span>
        </button>
        <button class="fi-download-all-btn" title="Download all weights">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M3 1v7m0 0L1 6M3 8l2-2M7 3v7m0 0L5 8M7 10l2-2M11 1v7m0 0L9 6M11 8l2-2M2 12.5h10" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span class="fi-download-all-label">All Weights</span>
        </button>
      </div>
      <div class="fi-feedback" style="display:none;"></div>
      <div class="fi-copy-hint">Click any property to copy its value</div>
    `;
    document.documentElement.appendChild(el);

    // Close
    el.querySelector('.fi-close-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      closePanel();
    });

    // Show feedback area with message and optional replica button
    function showFeedback(feedbackEl, message, fontName, showReplica) {
      feedbackEl.style.display = 'block';
      if (showReplica) {
        feedbackEl.innerHTML = `
          <div class="fi-feedback-text">${message}</div>
          <button class="fi-replica-btn">
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M6 1v4m0 0V9m0-4H2m4 0h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            Download similar font from Google Fonts
          </button>
        `;
        feedbackEl.querySelector('.fi-replica-btn').addEventListener('click', async (ev) => {
          ev.stopPropagation();
          const replicaBtn = feedbackEl.querySelector('.fi-replica-btn');
          replicaBtn.textContent = 'Searching Google Fonts...';
          replicaBtn.disabled = true;

          const result = await findReplica(fontName);
          if (result.success) {
            feedbackEl.innerHTML = `<div class="fi-feedback-success">Downloaded "${result.replicaName}" (${result.count} weights) as a replica</div>`;
            setTimeout(() => { feedbackEl.style.display = 'none'; }, 4000);
          } else {
            feedbackEl.innerHTML = `<div class="fi-feedback-text">No similar font found on Google Fonts.</div>`;
            setTimeout(() => { feedbackEl.style.display = 'none'; }, 3000);
          }
        });
      } else {
        feedbackEl.innerHTML = `<div class="fi-feedback-text">${message}</div>`;
        setTimeout(() => { feedbackEl.style.display = 'none'; }, 3000);
      }
    }

    // Download single
    el.querySelector('.fi-download-btn').addEventListener('click', async (e) => {
      e.stopPropagation();
      const fontName = el.querySelector('.fi-font-name').textContent;
      const btn = el.querySelector('.fi-download-btn');
      const label = btn.querySelector('.fi-download-label');
      const feedbackEl = el.querySelector('.fi-feedback');
      feedbackEl.style.display = 'none';
      label.textContent = 'Searching...';
      btn.classList.remove('fi-download-unavailable');
      btn.classList.add('fi-download-success');

      const result = await downloadFont(fontName, el._rawFamily, el._fontWeight, el._fontStyle);
      if (result.success) {
        label.textContent = 'Done!';
        setTimeout(() => { label.textContent = 'Download Font'; btn.classList.remove('fi-download-success'); }, 2500);
      } else {
        label.textContent = 'Unavailable';
        btn.classList.remove('fi-download-success');
        btn.classList.add('fi-download-unavailable');
        showFeedback(feedbackEl,
          'This font is protected or self-hosted with restricted access. The server blocks direct downloads.',
          fontName, true);
        setTimeout(() => { label.textContent = 'Download Font'; btn.classList.remove('fi-download-unavailable'); }, 3000);
      }
    });

    // Download all weights
    el.querySelector('.fi-download-all-btn').addEventListener('click', async (e) => {
      e.stopPropagation();
      const fontName = el.querySelector('.fi-font-name').textContent;
      const btn = el.querySelector('.fi-download-all-btn');
      const label = btn.querySelector('.fi-download-all-label');
      const feedbackEl = el.querySelector('.fi-feedback');
      feedbackEl.style.display = 'none';
      label.textContent = 'Searching...';
      btn.classList.remove('fi-download-unavailable');
      btn.classList.add('fi-download-success');

      const result = await downloadAllWeights(fontName, el._rawFamily);
      if (result.success) {
        label.textContent = `${result.count} file${result.count > 1 ? 's' : ''}`;
        setTimeout(() => { label.textContent = 'All Weights'; btn.classList.remove('fi-download-success'); }, 3000);
      } else {
        label.textContent = 'Unavailable';
        btn.classList.remove('fi-download-success');
        btn.classList.add('fi-download-unavailable');
        showFeedback(feedbackEl,
          'This font is protected or served from a restricted CDN. All download strategies failed.',
          fontName, true);
        setTimeout(() => { label.textContent = 'All Weights'; btn.classList.remove('fi-download-unavailable'); }, 3000);
      }
    });

    // Copy on property click
    el.querySelectorAll('.fi-prop').forEach(prop => {
      prop.style.cursor = 'pointer';
      prop.addEventListener('click', (e) => {
        e.stopPropagation();
        const text = prop.querySelector('.fi-prop-value').textContent.trim();
        navigator.clipboard.writeText(text).then(() => showCopied(e.clientX, e.clientY));
      });
    });

    return el;
  }

  function updatePanel(p, info) {
    // Store weight/style/rawFamily on the element for download button access
    p._fontWeight = info.weight;
    p._fontStyle = info.style;
    p._rawFamily = info.rawFamily;

    p.querySelector('.fi-font-name').textContent = info.family;
    const preview = p.querySelector('.fi-preview-text');
    preview.style.fontFamily = info.fullFamily;
    preview.style.fontWeight = info.weight;
    preview.style.fontStyle = info.style;

    p.querySelector('[data-field="size"]').textContent = info.size;
    p.querySelector('[data-field="weight"]').textContent = `${info.weight} - ${weightName(info.weight)}`;
    p.querySelector('[data-field="style"]').textContent = info.style;
    p.querySelector('[data-field="lineHeight"]').textContent = info.lineHeight;
    p.querySelector('[data-field="letterSpacing"]').textContent = info.letterSpacing;

    const hex = rgbToHex(info.color);
    p.querySelector('.fi-color-swatch').style.background = info.color;
    p.querySelector('.fi-color-hex').textContent = hex;
    p.querySelector('[data-field="fullFamily"]').textContent = info.fullFamily;
  }

  function closePanel() {
    if (panel) {
      panel.classList.remove('fi-visible');
      panel.remove();
      panel = null;
    }
  }

  function showCopied(x, y) {
    if (!copiedToast) {
      copiedToast = document.createElement('div');
      copiedToast.className = 'fi-copied';
      copiedToast.textContent = 'Copied!';
      document.documentElement.appendChild(copiedToast);
    }
    copiedToast.style.left = `${x}px`;
    copiedToast.style.top = `${y - 40}px`;
    copiedToast.classList.add('fi-visible');
    setTimeout(() => copiedToast.classList.remove('fi-visible'), 1200);
  }

  function positionElement(el, x, y) {
    const pad = 16;
    el.style.left = `${x + pad}px`;
    el.style.top = `${y + pad}px`;
    requestAnimationFrame(() => {
      const rect = el.getBoundingClientRect();
      let left = x + pad;
      let top = y + pad;
      if (left + rect.width > window.innerWidth - pad) left = x - rect.width - pad;
      if (top + rect.height > window.innerHeight - pad) top = y - rect.height - pad;
      el.style.left = `${Math.max(pad, left)}px`;
      el.style.top = `${Math.max(pad, top)}px`;
    });
  }

  // ── Event Handlers ──

  function onMouseMove(e) {
    if (!active) return;
    const target = e.target;
    if (!target || target.closest('.fi-tooltip') || target.closest('.fi-badge')) return;

    if (lastTarget && lastTarget !== target) {
      lastTarget.classList.remove('fi-highlight');
    }

    const hasText = target.childNodes && Array.from(target.childNodes).some(
      n => n.nodeType === Node.TEXT_NODE && n.textContent.trim()
    );

    if (!hasText) {
      hideBadge();
      lastTarget = null;
      return;
    }

    target.classList.add('fi-highlight');
    lastTarget = target;

    const info = getComputedFont(target);
    updateBadge(info, e.clientX, e.clientY);
  }

  function onMouseLeave() {
    if (lastTarget) {
      lastTarget.classList.remove('fi-highlight');
      lastTarget = null;
    }
    hideBadge();
  }

  function onClick(e) {
    if (!active || !lastTarget) return;
    if (e.target.closest('.fi-tooltip') || e.target.closest('.fi-badge')) return;

    e.preventDefault();
    e.stopPropagation();

    // Hide badge
    hideBadge();

    // Close existing panel
    closePanel();

    // Open full panel
    const info = getComputedFont(lastTarget);
    panel = createPanel();
    updatePanel(panel, info);
    positionElement(panel, e.clientX, e.clientY);

    // Show with animation
    requestAnimationFrame(() => {
      panel.classList.add('fi-visible');
    });
  }

  // ── Activation ──

  function activate() {
    active = true;
    document.addEventListener('mousemove', onMouseMove, true);
    document.addEventListener('mouseleave', onMouseLeave, true);
    document.addEventListener('click', onClick, true);
  }

  function deactivate() {
    active = false;
    if (lastTarget) {
      lastTarget.classList.remove('fi-highlight');
      lastTarget = null;
    }
    hideBadge();
    if (badge) { badge.remove(); badge = null; }
    closePanel();
    document.removeEventListener('mousemove', onMouseMove, true);
    document.removeEventListener('mouseleave', onMouseLeave, true);
    document.removeEventListener('click', onClick, true);
  }

  document.addEventListener('keydown', (e) => {
    if (e.altKey && e.key === 'f') {
      e.preventDefault();
      if (active) deactivate(); else activate();
    }
    if (e.key === 'Escape' && active) {
      if (panel) { closePanel(); } else { deactivate(); }
    }
  });

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'TOGGLE_INSPECTOR') {
      if (msg.active) activate(); else deactivate();
    } else if (msg.type === 'TOGGLE_PIN') {
      pinEnabled = msg.pinEnabled;
    } else if (msg.type === 'GET_STATE') {
      sendResponse({ active, pinEnabled });
    }
    return true;
  });
})();
