const toggleInspector = document.getElementById('toggleInspector');
const togglePin = document.getElementById('togglePin');

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function ensureContentScript(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: 'GET_STATE' });
    return response;
  } catch {
    // Content script not injected yet — inject it now
    await chrome.scripting.insertCSS({ target: { tabId }, files: ['content.css'] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    // Small delay to let the script initialize
    await new Promise(r => setTimeout(r, 100));
    try {
      return await chrome.tabs.sendMessage(tabId, { type: 'GET_STATE' });
    } catch {
      return null;
    }
  }
}

async function sendMsg(msg) {
  const tab = await getActiveTab();
  await ensureContentScript(tab.id);
  chrome.tabs.sendMessage(tab.id, msg);
}

// Load saved state
(async () => {
  const tab = await getActiveTab();
  const state = await ensureContentScript(tab.id);
  if (state) {
    toggleInspector.checked = state.active;
    togglePin.checked = state.pinEnabled;
  }
})();

toggleInspector.addEventListener('change', () => {
  sendMsg({ type: 'TOGGLE_INSPECTOR', active: toggleInspector.checked });
});

togglePin.addEventListener('change', () => {
  sendMsg({ type: 'TOGGLE_PIN', pinEnabled: togglePin.checked });
});
