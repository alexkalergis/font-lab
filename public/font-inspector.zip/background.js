chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'DOWNLOAD_FONT') {
    handleDownload(msg)
      .then(r => sendResponse(r))
      .catch(e => { console.error('[FI] Download error:', e); sendResponse({ success: false, reason: 'error' }); });
    return true;
  }
  if (msg.type === 'DOWNLOAD_ALL_WEIGHTS') {
    handleDownloadAllWeights(msg)
      .then(r => sendResponse(r))
      .catch(e => { console.error('[FI] Download all error:', e); sendResponse({ success: false, reason: 'error' }); });
    return true;
  }
  if (msg.type === 'FIND_REPLICA') {
    handleFindReplica(msg)
      .then(r => sendResponse(r))
      .catch(e => { console.error('[FI] Replica error:', e); sendResponse({ success: false }); });
    return true;
  }
});

const WEIGHT_NAMES = {
  '100': 'Thin', '200': 'ExtraLight', '300': 'Light',
  '400': 'Regular', '500': 'Medium', '600': 'SemiBold',
  '700': 'Bold', '800': 'ExtraBold', '900': 'Black'
};

// ── Replica mapping: proprietary/system fonts → Google Fonts alternatives ──

const FONT_REPLICAS = {
  'helvetica': 'Inter',
  'helvetica neue': 'Inter',
  'arial': 'Roboto',
  'futura': 'Jost',
  'avenir': 'Nunito',
  'avenir next': 'Nunito Sans',
  'proxima nova': 'Montserrat',
  'gotham': 'Urbanist',
  'gill sans': 'Lato',
  'franklin gothic': 'Libre Franklin',
  'garamond': 'EB Garamond',
  'palatino': 'Lora',
  'georgia': 'Merriweather',
  'times new roman': 'Noto Serif',
  'times': 'Noto Serif',
  'calibri': 'Carlito',
  'segoe ui': 'Open Sans',
  'san francisco': 'Inter',
  'sf pro': 'Inter',
  'sf pro display': 'Inter',
  'sf pro text': 'Inter',
  'sf mono': 'JetBrains Mono',
  'system-ui': 'Inter',
  '-apple-system': 'Inter',
  'blinkmacsystemfont': 'Inter',
  'trebuchet ms': 'Source Sans 3',
  'verdana': 'Open Sans',
  'tahoma': 'Open Sans',
  'century gothic': 'Questrial',
  'lucida grande': 'Lato',
  'lucida sans': 'Lato',
  'optima': 'Didact Gothic',
  'book antiqua': 'Crimson Text',
  'cambria': 'Merriweather',
  'rockwell': 'Rokkitt',
  'impact': 'Anton',
  'copperplate': 'Cinzel',
  'din': 'DM Sans',
  'din next': 'DM Sans',
  'brandon grotesque': 'Nunito',
  'myriad pro': 'Source Sans 3',
  'frutiger': 'Hind',
  'circular': 'DM Sans',
  'graphik': 'Work Sans',
  'neue haas grotesk': 'Inter',
  'akzidenz grotesk': 'Work Sans',
  'trade gothic': 'Oswald',
  'univers': 'Inter',
  'aktiv grotesk': 'Inter',
  'museo sans': 'Nunito Sans',
  'suisse intl': 'Inter',
  'walsheim': 'DM Sans',
};

// ── Google Fonts ──

async function getGoogleFontsVariants(fontFamily) {
  const encoded = encodeURIComponent(fontFamily);
  const url = `https://fonts.googleapis.com/css2?family=${encoded}:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap`;

  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const css = await res.text();
    return parseGoogleCSS(css, fontFamily);
  } catch {
    return [];
  }
}

// Check if a font name exists on Google Fonts (returns true/false)
async function existsOnGoogleFonts(fontFamily) {
  const encoded = encodeURIComponent(fontFamily);
  const url = `https://fonts.googleapis.com/css2?family=${encoded}&display=swap`;
  try {
    const res = await fetch(url);
    return res.ok;
  } catch {
    return false;
  }
}

function parseGoogleCSS(cssText, fontFamily) {
  const normalized = fontFamily.toLowerCase().replace(/['"]/g, '').trim();
  const results = [];
  const blocks = cssText.split(/@font-face\s*\{/);

  for (let i = 1; i < blocks.length; i++) {
    const block = blocks[i].split('}')[0];
    const familyMatch = block.match(/font-family\s*:\s*(['"])([^'"]+)\1/i);
    if (!familyMatch) continue;
    if (familyMatch[2].toLowerCase().trim() !== normalized) continue;

    const weightMatch = block.match(/font-weight\s*:\s*(\d+)/i);
    const styleMatch = block.match(/font-style\s*:\s*(italic|normal)/i);
    const urlMatch = block.match(/url\(([^)]+)\)/i);
    if (!urlMatch) continue;

    const weight = weightMatch ? weightMatch[1] : '400';
    const style = styleMatch ? styleMatch[1] : 'normal';
    const fontUrl = urlMatch[1].replace(/['"]/g, '').trim();

    if (!results.some(r => r.weight === weight && r.style === style)) {
      results.push({ url: fontUrl, weight, style });
    }
  }
  return results;
}

// ── Font name cleaning ──

function cleanFontName(name) {
  let cleaned = name.replace(/^__/, '').replace(/_[a-f0-9]{6,}$/i, '');
  cleaned = cleaned.replace(/_/g, ' ');
  return cleaned;
}

// Try Google Fonts with multiple name variations
async function tryGoogleFonts(fontFamily, rawFamily) {
  let gf = await getGoogleFontsVariants(fontFamily);
  if (gf.length > 0) return gf;

  if (rawFamily && rawFamily !== fontFamily) {
    const cleaned = cleanFontName(rawFamily);
    if (cleaned !== fontFamily) {
      gf = await getGoogleFontsVariants(cleaned);
      if (gf.length > 0) return gf;
    }
  }

  // Try stripping common suffixes
  const suffixes = [' Pro', ' Display', ' Text', ' Web', ' Neue', ' Next'];
  for (const suffix of suffixes) {
    if (fontFamily.endsWith(suffix)) {
      gf = await getGoogleFontsVariants(fontFamily.slice(0, -suffix.length));
      if (gf.length > 0) return gf;
    }
  }

  return [];
}

// ── Find replica font ──

async function handleFindReplica(msg) {
  const { fontFamily } = msg;
  const lower = fontFamily.toLowerCase().trim();
  console.log(`[FI] Finding replica for: "${fontFamily}"`);

  // 1. Check curated mapping
  const mapped = FONT_REPLICAS[lower];
  if (mapped) {
    const gf = await getGoogleFontsVariants(mapped);
    if (gf.length > 0) {
      console.log(`[FI] Replica found via mapping: ${mapped} (${gf.length} variants)`);
      return await downloadAsZip(gf, mapped, fontFamily);
    }
  }

  // 2. Try partial name matching on Google Fonts
  //    e.g. "Custom Sans Pro" → try "Custom Sans", then "Custom"
  const words = fontFamily.split(/\s+/);
  for (let len = words.length; len >= 1; len--) {
    const candidate = words.slice(0, len).join(' ');
    if (candidate.length < 3) continue;
    const gf = await getGoogleFontsVariants(candidate);
    if (gf.length > 0) {
      console.log(`[FI] Replica found via partial match: ${candidate}`);
      return await downloadAsZip(gf, candidate, fontFamily);
    }
  }

  // 3. Try the mapped name with partial matching
  if (mapped) {
    console.log(`[FI] Mapped replica "${mapped}" exists but failed to get variants`);
  }

  console.log('[FI] No replica found');
  return { success: false, reason: 'no_replica' };
}

async function downloadAsZip(fonts, replicaName, originalName) {
  const files = [];
  for (const font of fonts) {
    try {
      const res = await fetch(font.url);
      if (!res.ok) continue;
      const data = new Uint8Array(await res.arrayBuffer());
      const format = isValidFontFile(data);
      if (!format) continue;
      const filename = buildFilename(font.url, replicaName, font.weight, font.style, format);
      files.push({ name: filename, data });
    } catch {}
  }

  if (files.length === 0) return { success: false, reason: 'download_failed' };

  const unique = deduplicateFiles(files);
  const zipData = createZip(unique);
  const blob = new Blob([zipData], { type: 'application/zip' });
  const blobUrl = URL.createObjectURL(blob);
  const safeName = replicaName.replace(/[^a-zA-Z0-9]/g, '');

  try {
    await chrome.downloads.download({
      url: blobUrl,
      filename: `${safeName}-Replica-AllWeights.zip`,
      saveAs: true
    });
    setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    return { success: true, count: unique.length, replicaName };
  } catch (e) {
    URL.revokeObjectURL(blobUrl);
    return { success: false, reason: String(e) };
  }
}

// ── Download single font ──
// Strategy order (rethought):
// 1. Browser-parsed @font-face — most direct, browser already resolved these
// 2. Direct URL from performance API — the actual URL the browser loaded
// 3. Google Fonts API — works for Google Fonts, gives the right weight
// 4. Font resource URL matching — match loaded URLs by name
// 5. Single font URL fallback

async function handleDownload(msg) {
  const { fontFamily, rawFamily, parsedFontFaces, directUrl, fontResourceUrls, inspectedWeight, inspectedStyle } = msg;
  const weight = inspectedWeight || '400';
  const style = inspectedStyle || 'normal';

  console.log(`[FI] Download single: "${fontFamily}" (raw: "${rawFamily || ''}") weight=${weight} style=${style}`);

  // 1. Browser-parsed @font-face (same-origin stylesheets) — most reliable
  if (parsedFontFaces && parsedFontFaces.length > 0) {
    const match = parsedFontFaces.find(f => f.weight === weight && f.style === style)
      || parsedFontFaces.find(f => f.weight === weight)
      || parsedFontFaces.find(f => f.isVariableWeight)
      || parsedFontFaces[0];
    if (match) {
      console.log(`[FI] Trying parsed font face: ${match.url.substring(0, 80)}`);
      const r = await tryDownload(match.url, fontFamily, weight, style, true);
      if (r.success) return r;
    }
  }

  // 2. Direct URL from performance API
  if (directUrl) {
    console.log(`[FI] Trying performance API URL: ${directUrl.substring(0, 80)}`);
    const r = await tryDownload(directUrl, fontFamily, weight, style, true);
    if (r.success) return r;
  }

  // 3. Google Fonts (try cleaned + raw names)
  const gf = await tryGoogleFonts(fontFamily, rawFamily);
  if (gf.length > 0) {
    const match = gf.find(f => f.weight === weight && f.style === style)
      || gf.find(f => f.weight === weight)
      || gf[0];
    console.log(`[FI] Trying Google Fonts: ${match.url.substring(0, 80)}`);
    const r = await tryDownload(match.url, fontFamily, weight, style, true);
    if (r.success) return r;
  }

  // 4. Font resource URLs — match against all name variations
  const namesToTry = buildNameVariations(fontFamily, rawFamily);
  for (const u of (fontResourceUrls || [])) {
    const urlClean = u.toLowerCase().replace(/[^a-z0-9]/g, '');
    for (const name of namesToTry) {
      if (name && urlClean.includes(name)) {
        const r = await tryDownload(u, fontFamily, weight, style, true);
        if (r.success) return r;
        break;
      }
    }
  }

  // 5. If there's only 1 font on the page, it's probably the one
  if (fontResourceUrls && fontResourceUrls.length === 1) {
    const r = await tryDownload(fontResourceUrls[0], fontFamily, weight, style, true);
    if (r.success) return r;
  }

  console.log('[FI] All strategies failed for single download');
  return { success: false, reason: 'protected' };
}

// ── Download ALL weights ──
// Strategy order (rethought):
// 1. Browser-parsed @font-face — direct from the CSS the browser loaded
// 2. Google Fonts API — gives ALL weights, even ones the page didn't load
// 3. Fetch & parse stylesheets — cross-origin fallback
// 4. Font resource URLs by name
// 5. All font resource URLs (last resort)

async function handleDownloadAllWeights(msg) {
  const { fontFamily, rawFamily, parsedFontFaces, fontResourceUrls, stylesheetUrls, inlineFontFaces, documentFonts, pageUrl } = msg;
  let fonts = [];
  let strategy = '';

  console.log(`[FI] Download all weights: "${fontFamily}" (raw: "${rawFamily || ''}")`);
  console.log(`[FI] parsedFontFaces: ${(parsedFontFaces || []).length}, resourceUrls: ${(fontResourceUrls || []).length}, docFonts: ${(documentFonts || []).length}`);

  // Strategy 1: Browser-parsed @font-face rules (same-origin stylesheets)
  // These are the actual CSS rules the browser parsed — most reliable source
  if (parsedFontFaces && parsedFontFaces.length > 0) {
    console.log(`[FI] Using ${parsedFontFaces.length} browser-parsed @font-face rules`);
    fonts = parsedFontFaces.map(f => ({
      url: f.url,
      weight: f.isVariableWeight ? null : f.weight,
      style: (f.style && f.style !== 'normal') ? f.style : null,
    }));
    strategy = 'parsed';
  }

  // Strategy 2: Google Fonts (gives ALL weights even if page only uses some)
  if (fonts.length === 0) {
    const gf = await tryGoogleFonts(fontFamily, rawFamily);
    if (gf.length > 0) {
      console.log(`[FI] Google Fonts returned ${gf.length} variants`);
      fonts = gf;
      strategy = 'google';
    }
  }

  // Strategy 3: Fetch and parse all stylesheets (works for cross-origin)
  if (fonts.length === 0) {
    console.log('[FI] Trying cross-origin stylesheet parsing...');
    fonts = await parseCrossOriginStylesheets(fontFamily, rawFamily, stylesheetUrls, inlineFontFaces, pageUrl);
    if (fonts.length > 0) strategy = 'css-parse';
    console.log(`[FI] CSS parsing found ${fonts.length} variants`);
  }

  // Strategy 4: Font resource URLs matching the font name
  if (fonts.length === 0 && fontResourceUrls && fontResourceUrls.length > 0) {
    const namesToTry = buildNameVariations(fontFamily, rawFamily);
    const matched = fontResourceUrls.filter(u => {
      const urlClean = u.toLowerCase().replace(/[^a-z0-9]/g, '');
      for (const name of namesToTry) {
        if (name && urlClean.includes(name)) return true;
      }
      return false;
    });

    if (matched.length > 0) {
      console.log(`[FI] Font resource URLs matched ${matched.length} by name`);
      fonts = matched.map(url => ({ url, weight: null, style: null }));
      strategy = 'url-match';
    }
  }

  // Strategy 5: All font resource URLs (absolute last resort)
  if (fonts.length === 0 && fontResourceUrls && fontResourceUrls.length > 0) {
    console.log(`[FI] Last resort: all ${fontResourceUrls.length} font resource URLs`);
    fonts = fontResourceUrls.map(url => ({ url, weight: null, style: null }));
    strategy = 'all-urls';
  }

  if (fonts.length === 0) {
    console.log('[FI] No fonts found by any strategy');
    return { success: false, reason: 'protected' };
  }

  // Fetch all files and build ZIP
  console.log(`[FI] Fetching ${fonts.length} font files (strategy: ${strategy})...`);
  const files = [];
  for (const font of fonts) {
    try {
      const res = await fetch(font.url);
      if (!res.ok) continue;
      const data = new Uint8Array(await res.arrayBuffer());
      const format = isValidFontFile(data);
      if (!format) {
        console.log(`[FI] Not a valid font: ${data.length}B, header: ${data.slice(0, 4).join(',')}`);
        continue;
      }
      const filename = buildFilename(font.url, fontFamily, font.weight, font.style, format);
      files.push({ name: filename, data });
      console.log(`[FI] OK: ${filename} (${format}, ${data.length}B)`);
    } catch (e) {
      console.log(`[FI] Fetch failed: ${e.message}`);
    }
  }

  if (files.length === 0) {
    console.log('[FI] All fetches failed — font is protected');
    return { success: false, reason: 'protected' };
  }

  const unique = deduplicateFiles(files);
  console.log(`[FI] ${files.length} fetched, ${unique.length} unique`);

  const zipData = createZip(unique);
  const blob = new Blob([zipData], { type: 'application/zip' });
  const blobUrl = URL.createObjectURL(blob);
  const safeName = fontFamily.replace(/[^a-zA-Z0-9]/g, '');

  try {
    await chrome.downloads.download({
      url: blobUrl,
      filename: `${safeName}-AllWeights.zip`,
      saveAs: true
    });
    setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    return { success: true, count: unique.length };
  } catch (e) {
    URL.revokeObjectURL(blobUrl);
    return { success: false, reason: String(e) };
  }
}

// ── Shared helpers ──

function buildNameVariations(fontFamily, rawFamily) {
  const names = new Set([fontFamily.toLowerCase().replace(/[^a-z0-9]/g, '')]);
  if (rawFamily) {
    names.add(rawFamily.toLowerCase().replace(/[^a-z0-9]/g, ''));
    names.add(cleanFontName(rawFamily).toLowerCase().replace(/[^a-z0-9]/g, ''));
  }
  return names;
}

async function parseCrossOriginStylesheets(fontFamily, rawFamily, stylesheetUrls, inlineFontFaces, pageUrl) {
  const fonts = [];
  const cssSources = [];

  for (const cssUrl of (stylesheetUrls || [])) {
    try {
      const res = await fetch(cssUrl);
      if (!res.ok) continue;
      cssSources.push({ text: await res.text(), baseUrl: cssUrl });
    } catch {}
  }
  for (const rule of (inlineFontFaces || [])) {
    cssSources.push({ text: rule, baseUrl: pageUrl || '' });
  }

  const namesToMatch = new Set();
  namesToMatch.add(fontFamily.toLowerCase().replace(/['"]/g, '').trim());
  if (rawFamily) {
    namesToMatch.add(rawFamily.toLowerCase().replace(/['"]/g, '').trim());
    namesToMatch.add(cleanFontName(rawFamily).toLowerCase().replace(/['"]/g, '').trim());
  }

  for (const { text, baseUrl } of cssSources) {
    const blocks = text.split(/@font-face\s*\{/);
    for (let i = 1; i < blocks.length; i++) {
      const block = blocks[i].split('}')[0];
      const fm = block.match(/font-family\s*:\s*(['"]?)([^;'"]+)\1/i);
      if (!fm) continue;
      const fam = fm[2].toLowerCase().replace(/['"]/g, '').trim();
      const famCompact = fam.replace(/[\s_-]/g, '');

      let matched = false;
      for (const name of namesToMatch) {
        if (fam === name || famCompact === name.replace(/[\s_-]/g, '')) { matched = true; break; }
      }
      if (!matched) continue;

      const wm = block.match(/font-weight\s*:\s*(\d+)/i);
      const sm = block.match(/font-style\s*:\s*(italic|normal|oblique)/i);
      const urls = [...block.matchAll(/url\(["']?([^"')]+)["']?\)/g)].map(m => m[1]);
      if (urls.length === 0) continue;

      const preferred = urls.find(u => /\.woff2/i.test(u)) || urls.find(u => /\.woff/i.test(u)) || urls[0];
      let resolved;
      try { resolved = new URL(preferred, baseUrl).href; } catch { resolved = preferred; }

      if (!fonts.some(f => f.url === resolved)) {
        fonts.push({ url: resolved, weight: wm ? wm[1] : null, style: sm ? sm[1] : null });
      }
    }
  }

  return fonts;
}

function deduplicateFiles(files) {
  const unique = [];
  const seen = new Set();
  for (const file of files) {
    const hash = simpleHash(file.data);
    if (!seen.has(hash)) {
      seen.add(hash);
      unique.push(file);
    }
  }
  return unique;
}

// ── Font validation ──

function isValidFontFile(data) {
  if (data.length < 12) return false;
  if (data[0] === 0x77 && data[1] === 0x4F && data[2] === 0x46 && data[3] === 0x32) return 'woff2';
  if (data[0] === 0x77 && data[1] === 0x4F && data[2] === 0x46 && data[3] === 0x46) return 'woff';
  if (data[0] === 0x00 && data[1] === 0x01 && data[2] === 0x00 && data[3] === 0x00) return 'ttf';
  if (data[0] === 0x4F && data[1] === 0x54 && data[2] === 0x54 && data[3] === 0x4F) return 'otf';
  if (data[0] === 0x74 && data[1] === 0x74 && data[2] === 0x63 && data[3] === 0x66) return 'ttc';
  return false;
}

// ── Filename & helpers ──

function simpleHash(data) {
  let h = 0;
  const step = Math.max(1, Math.floor(data.length / 1000));
  for (let i = 0; i < data.length; i += step) {
    h = (h * 31 + data[i]) | 0;
  }
  return `${h}_${data.length}`;
}

function guessWeightFromUrl(url) {
  const lower = url.toLowerCase();
  const numMatch = lower.match(/[_\-./](100|200|300|400|500|600|700|800|900)[_\-./]/);
  if (numMatch) return numMatch[1];

  const nameToNum = {
    thin: '100', extralight: '200', ultralight: '200', light: '300',
    regular: '400', medium: '500', semibold: '600', demibold: '600',
    bold: '700', extrabold: '800', ultrabold: '800', black: '900', heavy: '900'
  };
  const nameMatch = lower.match(/[_\-./](thin|extralight|ultralight|light|regular|medium|semibold|demibold|bold|extrabold|ultrabold|black|heavy)[_\-./]/i);
  if (nameMatch) return nameToNum[nameMatch[1].toLowerCase()] || null;

  return null;
}

function buildFilename(url, fontFamily, weight, style, validatedFormat) {
  let ext;
  if (validatedFormat) {
    ext = `.${validatedFormat}`;
  } else {
    const extMatch = url.match(/\.(woff2|woff|ttf|otf|eot)/i);
    ext = extMatch ? `.${extMatch[1].toLowerCase()}` : '.woff2';
  }
  const safeName = fontFamily.replace(/[^a-zA-Z0-9 ]/g, '').replace(/\s+/g, '');
  const weightNum = weight || guessWeightFromUrl(url) || '400';
  const weightLabel = WEIGHT_NAMES[weightNum] || 'Regular';
  const styleSuffix = (style && style !== 'normal') ? `-${style}` : '';
  return `${safeName}-${weightLabel}-${weightNum}${styleSuffix}${ext}`;
}

async function tryDownload(url, fontFamily, weight, style, saveAs) {
  const filename = buildFilename(url, fontFamily, weight, style);
  console.log(`[FI] tryDownload: ${filename}`);

  try {
    await chrome.downloads.download({ url, filename, saveAs });
    return { success: true };
  } catch (e) {
    console.log(`[FI] Direct download failed, trying blob...`, e.message);
    try {
      const res = await fetch(url);
      if (!res.ok) return { success: false };
      const arrayBuf = await res.arrayBuffer();
      const check = isValidFontFile(new Uint8Array(arrayBuf));
      if (!check) return { success: false };
      const blob = new Blob([arrayBuf]);
      const blobUrl = URL.createObjectURL(blob);
      await chrome.downloads.download({ url: blobUrl, filename, saveAs });
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
      return { success: true };
    } catch (e2) {
      console.log(`[FI] Blob download also failed`, e2.message);
      return { success: false };
    }
  }
}

// ── ZIP creator ──

function createZip(files) {
  const localHeaders = [];
  const centralHeaders = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = new TextEncoder().encode(file.name);
    const crc = crc32(file.data);
    const size = file.data.length;

    const local = new Uint8Array(30 + nameBytes.length + size);
    const lv = new DataView(local.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0, true);
    lv.setUint16(8, 0, true);
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, size, true);
    lv.setUint32(22, size, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    local.set(nameBytes, 30);
    local.set(file.data, 30 + nameBytes.length);
    localHeaders.push(local);

    const central = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(central.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, size, true);
    cv.setUint32(24, size, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    central.set(nameBytes, 46);
    centralHeaders.push(central);

    offset += local.length;
  }

  const centralDirSize = centralHeaders.reduce((s, c) => s + c.length, 0);
  const eocdr = new Uint8Array(22);
  const ev = new DataView(eocdr.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, files.length, true);
  ev.setUint16(10, files.length, true);
  ev.setUint32(12, centralDirSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + centralDirSize + 22;
  const zip = new Uint8Array(totalSize);
  let pos = 0;
  for (const lh of localHeaders) { zip.set(lh, pos); pos += lh.length; }
  for (const ch of centralHeaders) { zip.set(ch, pos); pos += ch.length; }
  zip.set(eocdr, pos);
  return zip;
}

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[i] = c;
  }
  return t;
})();

function crc32(data) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < data.length; i++) crc = CRC_TABLE[(crc ^ data[i]) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}
